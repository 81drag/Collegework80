<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact me</title>
    <style type="text/css">

        html
        {
            background-color:#b3cccc;
        }
    </style>
</head>
<body>
<main>

    <form method="POST"  action="Contactform.php">
        <input type="text" name="name" placeholder="Full name">
        <input type="text" name="mail" placeholder="E-mail">
        <input type="text" name="subject" placeholder="Subject">
        <input type="text" name="Phone number" placeholder="Your Number">
        <textarea name="Message" placeholder="Message"></textarea>
        <button name="submit">  <input type="submit"/> </button>

    </form>



</main>
</body>
</html>